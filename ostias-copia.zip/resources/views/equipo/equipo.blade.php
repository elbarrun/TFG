@extends('layout.public')
@section('content')

    <div class="container-fluid">
        <div class="card-loyola mt-5">
            <div class="row g-0">
                <div class="col-12 col-sm-8">
                    <h5 class="card-title mb-4">Nombre equipo</h5>
                    <img src="{{asset('img/equipo.jpg')}}" class="img-fluid w-100 mt-md-2" alt="card-horizontal-image">
                </div>
                <div class="col-12 col-sm-4 mt-md-5">
                    <p class="card-text">Nombre Jugador</p>
                    <p class="card-text">Nombre Jugador</p>
                    <p class="card-text">Nombre Jugador</p>
                    <p class="card-text">Nombre Jugador</p>
                    <p class="card-text">Nombre Jugador</p>
                    <p class="card-text">Nombre Jugador</p>
                    <p class="card-text">Nombre Jugador</p>
                    <p class="card-text">Nombre Jugador</p>
                    <p class="card-text">Nombre Jugador</p>
                    <p class="card-text">Nombre Jugador</p>
                </div>
            </div>
        </div>
        <div class="card-loyola mt-5">
            <div class="row g-0">
                <div class="col-12 col-sm-8">
                    <h5 class="card-title mb-4">Nombre equipo</h5>
                    <img src="{{asset('img/equipo.jpg')}}"  class="img-fluid w-100 mt-md-2" alt="card-horizontal-image">
                </div>
                <div class="col-12 col-sm-4 mt-md-5">
                    <p class="card-text">Nombre Jugador</p>
                    <p class="card-text">Nombre Jugador</p>
                    <p class="card-text">Nombre Jugador</p>
                    <p class="card-text">Nombre Jugador</p>
                    <p class="card-text">Nombre Jugador</p>
                    <p class="card-text">Nombre Jugador</p>
                    <p class="card-text">Nombre Jugador</p>
                    <p class="card-text">Nombre Jugador</p>
                    <p class="card-text">Nombre Jugador</p>
                    <p class="card-text">Nombre Jugador</p>
                </div>
            </div>
        </div>
    </div>
    @endsection
